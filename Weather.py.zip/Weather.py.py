import requests

api_key =  "c3061ea8ebfec915f59895bbd17017f9"

city = input("Enter city name: ")

if city == "":
    print("Please enter a city name")
else:
    url = f"https://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}&units=metric"
    
    try:
        response = requests.get(url)
        data = response.json()

        if response.status_code != 200:
            print("City not found")
        else:
            temp = data["main"]["temp"]
            humidity = data["main"]["humidity"]
            condition = data["weather"][0]["main"]

            print("Temperature:", temp, "°C")
            print("Humidity:", humidity, "%")
            print("Condition:", condition)

    except:
        print("Error fetching data")
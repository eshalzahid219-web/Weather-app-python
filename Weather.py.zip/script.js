async function getWeather(){

    const city = document.getElementById("cityInput").value;

    // Validation
    if(city === ""){
        alert("Please enter city name");
        return;
    }

    const apiKey = "c3061ea8ebfec915f59895bbd17017f9";

    const url =
    `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

    try{

        const response = await fetch(url);

        // Error handling
        if(!response.ok){
            throw new Error("City not found");
        }

        const data = await response.json();

        document.getElementById("temp").innerHTML =
        Math.round(data.main.temp) + "°C";

        document.getElementById("city").innerHTML =
        data.name;

        document.getElementById("condition").innerHTML =
        data.weather[0].main;

        document.getElementById("humidity").innerHTML =
        data.main.humidity + "%";

        document.getElementById("wind").innerHTML =
        data.wind.speed + " km/h";

        const icon = data.weather[0].icon;

        document.getElementById("weatherIcon").src =
        `https://openweathermap.org/img/wn/${icon}@2x.png`;

    }

    catch(error){
        alert(error.message);
    }

}
